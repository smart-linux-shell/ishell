#include <terminal_multiplexer.hpp>

int main() {
    TerminalMultiplexer multiplexer;
    multiplexer.run();
    return 0;
}