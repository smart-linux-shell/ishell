#ifndef AGENT_HPP
#define AGENT_HPP
void agent();
#endif
